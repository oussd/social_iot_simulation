import logging
from datetime import datetime
import os
from typing import Dict, List

class SimulationLogger:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SimulationLogger, cls).__new__(cls)
            cls._instance._initialize_logger()
        return cls._instance
    
    def _initialize_logger(self):
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.makedirs('logs')
            
        # Create a logger
        self.logger = logging.getLogger('simulation')
        self.logger.setLevel(logging.INFO)
        
        # Create a file handler with date in filename
        current_date = datetime.now().strftime('%Y%m%d_%H%M%S')
        file_handler = logging.FileHandler(f'logs/simulation_{current_date}.log')
        file_handler.setLevel(logging.INFO)
        
        # Create a console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Create a formatter
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers to logger
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        # Initialize metrics storage
        self.simulation_metrics = {}
    
    def log_event(self, device_name, message, level='info'):
        """Log an event with the specified level"""
        log_func = getattr(self.logger, level.lower())
        log_func(f"{device_name}: {message}")
    
    def log_error(self, device_name, message):
        """Log an error event"""
        self.log_event(device_name, message, 'error')
    
    def log_warning(self, device_name, message):
        """Log a warning event"""
        self.log_event(device_name, message, 'warning')
    
    def log_info(self, device_name, message):
        """Log an info event"""
        self.log_event(device_name, message, 'info')

    def store_simulation_metrics(self, simulation_type: str, with_negotiation: bool, metrics: Dict):
        """Store metrics for a simulation run"""
        if simulation_type not in self.simulation_metrics:
            self.simulation_metrics[simulation_type] = {}
        self.simulation_metrics[simulation_type][with_negotiation] = metrics

    def log_comparison(self, simulation_type: str):
        """Log comparison between negotiation on/off for a simulation type"""
        if simulation_type not in self.simulation_metrics:
            return

        metrics = self.simulation_metrics[simulation_type]
        if len(metrics) != 2:  # Need both with and without negotiation
            return

        with_neg = metrics[True]
        without_neg = metrics[False]

        comparison = [
            f"\n=== {simulation_type} Comparison ===",
            "Metric                    | With Negotiation | Without Negotiation | Difference",
            "-------------------------|------------------|---------------------|------------",
            f"Average Trust Score      | {with_neg['avg_trust']:15.2f} | {without_neg['avg_trust']:19.2f} | {with_neg['avg_trust'] - without_neg['avg_trust']:10.2f}",
            f"Total Tasks Completed    | {with_neg['tasks_completed']:15d} | {without_neg['tasks_completed']:19d} | {with_neg['tasks_completed'] - without_neg['tasks_completed']:10d}",
            f"Total Tasks Failed       | {with_neg['tasks_failed']:15d} | {without_neg['tasks_failed']:19d} | {with_neg['tasks_failed'] - without_neg['tasks_failed']:10d}",
            f"Average Load             | {with_neg['avg_load']:15.2f} | {without_neg['avg_load']:19.2f} | {with_neg['avg_load'] - without_neg['avg_load']:10.2f}",
            f"Total Misuse Count       | {with_neg['total_misuse']:15d} | {without_neg['total_misuse']:19d} | {with_neg['total_misuse'] - without_neg['total_misuse']:10d}",
            f"Total Blame Count        | {with_neg['total_blame']:15d} | {without_neg['total_blame']:19d} | {with_neg['total_blame'] - without_neg['total_blame']:10d}",
            f"Success Rate             | {with_neg['success_rate']:15.2f}% | {without_neg['success_rate']:19.2f}% | {with_neg['success_rate'] - without_neg['success_rate']:10.2f}%"
        ]

        # Log to both file and console
        for line in comparison:
            self.logger.info(line) 