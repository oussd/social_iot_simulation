import random
from ..devices.sensing_device import SensingDevice
from ..devices.actuating_device import ActuatingDevice
from ..devices.communicating_device import CommunicatingDevice
from ..devices.composite_device import CompositeDevice
from ..utils.logger import SimulationLogger


class LabSimulation:
    def __init__(self, negotiation=True, num_devices=10):
        self.negotiation = negotiation
        self.num_devices = num_devices
        self.devices = []
        self.time_frame = 24 * 60  # simulate 24 hours in minutes
        self.logger = SimulationLogger()
        self.metrics = {
            'tasks_completed': 0,
            'tasks_failed': 0,
            'total_load': 0,
            'total_misuse': 0,
            'total_blame': 0
        }
        self.logger.log_info("Simulation", f"Initializing Lab Simulation with {num_devices} devices (Negotiation: {negotiation})")

    def setup_devices(self):
        device_types = {
            'sensing': 0,
            'actuating': 0,
            'communicating': 0,
            'composite': 0
        }

        for i in range(self.num_devices):
            if i % 4 == 0:
                device = SensingDevice(f"sens{i}", f"SensDevice{i}")
                device_types['sensing'] += 1
                self.logger.log_info(
                    "Device Creation",
                    f"Created Sensing Device: {device.name} "
                    f"(ID: {device.device_id}, Type: temperature)"
                )
            elif i % 4 == 1:
                device = ActuatingDevice(f"act{i}", f"ActDevice{i}")
                device_types['actuating'] += 1
                self.logger.log_info(
                    "Device Creation",
                    f"Created Actuating Device: {device.name} "
                    f"(ID: {device.device_id}, Type: switch)"
                )
            elif i % 4 == 2:
                device = CommunicatingDevice(f"comm{i}", f"CommDevice{i}")
                device_types['communicating'] += 1
                self.logger.log_info(
                    "Device Creation",
                    f"Created Communicating Device: {device.name} "
                    f"(ID: {device.device_id})"
                )
            else:
                device = CompositeDevice(f"comp{i}", f"CompDevice{i}")
                device_types['composite'] += 1
                self.logger.log_info(
                    "Device Creation",
                    f"Created Composite Device: {device.name} "
                    f"(ID: {device.device_id})"
                )
            self.devices.append(device)

        # Log device type distribution
        self.logger.log_info(
            "Device Distribution",
            f"Total Devices: {self.num_devices}\n"
            f"- Sensing Devices: {device_types['sensing']}\n"
            f"- Actuating Devices: {device_types['actuating']}\n"
            f"- Communicating Devices: {device_types['communicating']}\n"
            f"- Composite Devices: {device_types['composite']}"
        )

        # Connect devices with relationships
        relationship_count = {'work_with_me': 0, 'back_me': 0}
        for d1 in self.devices:
            for d2 in self.devices:
                if d1 != d2 and random.random() < 0.3:
                    d1.add_relationship('work_with_me', d2)
                    relationship_count['work_with_me'] += 1
                if d1 != d2 and random.random() < 0.2:
                    d1.add_relationship('back_me', d2)
                    relationship_count['back_me'] += 1

        # Log relationship distribution
        self.logger.log_info(
            "Relationship Distribution",
            f"Total Relationships:\n"
            f"- Work With Me: {relationship_count['work_with_me']}\n"
            f"- Back Me: {relationship_count['back_me']}"
        )

    def simulate_cycle(self, minute):
        for device in self.devices:
            load_variation = random.randint(5, 20)
            success = False
            
            if isinstance(device, SensingDevice):
                success = device.sense() is not None
            elif isinstance(device, ActuatingDevice):
                success = device.actuate("ON" if minute % 2 == 0 else "OFF")
            elif isinstance(device, CommunicatingDevice):
                target = random.choice(self.devices)
                if target != device:
                    device.connect_device(target)
                    success = device.transmit("status update", target)
            elif isinstance(device, CompositeDevice):
                task = random.choice(["sense", "actuate", "transmit"])
                details = {"command": "ON"} if task == "actuate" else {"message": "hello", "target": random.choice(self.devices)}
                success = device.handle_request(random.choice(self.devices), task, load=load_variation, details=details)

            if success:
                self.metrics['tasks_completed'] += 1
            else:
                self.metrics['tasks_failed'] += 1

            self.metrics['total_load'] += device.current_load
            self.metrics['total_misuse'] += device.misuse_count
            self.metrics['total_blame'] += device.blame_count

            device.reduce_load()

    def run(self):
        self.logger.log_info("Simulation", f"Starting Lab Simulation (Negotiation: {self.negotiation})")
        self.setup_devices()
        for minute in range(self.time_frame):
            self.simulate_cycle(minute)
        self.report()

    def report(self):
        self.logger.log_info("Simulation", "\n=== Simulation Report ===")
        for device in self.devices:
            device.report_status()

        # Calculate final metrics
        num_devices = len(self.devices)
        total_tasks = self.metrics['tasks_completed'] + self.metrics['tasks_failed']
        
        final_metrics = {
            'avg_trust': sum(d.trust_score for d in self.devices) / num_devices,
            'tasks_completed': self.metrics['tasks_completed'],
            'tasks_failed': self.metrics['tasks_failed'],
            'avg_load': self.metrics['total_load'] / (num_devices * self.time_frame),
            'total_misuse': self.metrics['total_misuse'],
            'total_blame': self.metrics['total_blame'],
            'success_rate': (self.metrics['tasks_completed'] / total_tasks * 100) if total_tasks > 0 else 0
        }

        # Store metrics for comparison
        self.logger.store_simulation_metrics("Lab Simulation", self.negotiation, final_metrics)
        
        # Log comparison if both runs are complete
        self.logger.log_comparison("Lab Simulation")
