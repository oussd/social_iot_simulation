from .device import Device

class ActuatingDevice(Device):
    def __init__(self, device_id, name, max_load=100, actuator_type="switch"):
        super().__init__(device_id, name, max_load)
        self.actuator_type = actuator_type
        self.current_state = "OFF"

    def actuate(self, command):
        if self.current_load >= self.max_load:
            self.log_event(f"Actuation failed: overloaded.")
            self.update_trust(success=False)
            return False

        self.current_state = command
        self.current_load += 10
        self.log_event(f"Actuated {self.actuator_type} to {command}")
        self.update_trust(success=True)
        return True

    def handle_request(self, from_device, task_type, load=10, details=None):
        if from_device in [d['device'] for d in self.relationships['avoid_me']]:
            self.log_event(f"Rejected request from avoided device {from_device.name}")
            return False

        if task_type != 'actuate':
            self.log_event(f"Rejected unknown task type '{task_type}'")
            return False

        command = details.get('command') if details else "ON"

        if self.negotiate_load(load):
            success = self.actuate(command)
            if success:
                self.log_event(f"Accepted actuation request from {from_device.name} with command '{command}'")
                self.update_trust(success=True)
                return True
            else:
                # Try backup if available
                for rel in self.relationships['back_me']:
                    backup = rel['device']
                    self.log_event(f"Requesting backup actuation from {backup.name}")
                    return backup.handle_request(self, 'actuate', load, details)
        else:
            self.log_event(f"Rejected actuation request from {from_device.name} (overload)")
            self.update_trust(success=False)
            return False

    def report_status(self):
        super().report_status()
        print(f"{self.name} | Actuator type: {self.actuator_type} | State: {self.current_state}")
