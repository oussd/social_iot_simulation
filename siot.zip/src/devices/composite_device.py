from .device import Device

class CompositeDevice(Device):
    def __init__(self, device_id, name, max_load=150, capabilities=None):
        super().__init__(device_id, name, max_load)
        self.capabilities = capabilities or ["sense", "actuate", "transmit"]
        self.sub_devices = []
        self.worker_devices = []  # Devices that work for this composite device

    def add_sub_device(self, device):
        self.sub_devices.append(device)
        self.log_event(f"Added sub-device {device.name}")

    def add_worker(self, device, constraints=None):
        """Add a device as a worker with specific constraints."""
        if device not in self.worker_devices:
            self.worker_devices.append(device)
            device.add_controller(self, constraints)
            self.log_event(f"Added {device.name} as worker")
            return True
        return False

    def remove_worker(self, device):
        """Remove a device from the worker list."""
        if device in self.worker_devices:
            self.worker_devices.remove(device)
            device.remove_controller(self)
            self.log_event(f"Removed {device.name} as worker")

    def delegate_task(self, task_type, details=None):
        """Delegate a task to an appropriate worker device."""
        # First try to delegate to workers
        for worker in self.worker_devices:
            if task_type in getattr(worker, 'sensor_type', '') or \
               task_type in getattr(worker, 'actuator_type', '') or \
               isinstance(worker, Device):
                self.log_event(f"Delegating '{task_type}' to worker {worker.name}")
                return worker.handle_request(self, task_type, load=10, details=details)
        
        # If no worker can handle it, try sub-devices
        for sub in self.sub_devices:
            if task_type in getattr(sub, 'sensor_type', '') or \
               task_type in getattr(sub, 'actuator_type', '') or \
               isinstance(sub, Device):
                self.log_event(f"Delegating '{task_type}' to sub-device {sub.name}")
                return sub.handle_request(self, task_type, load=10, details=details)
        
        self.log_event(f"No device could handle '{task_type}'")
        return False

    def handle_request(self, from_device, task_type, load=10, details=None):
        if from_device in [d['device'] for d in self.relationships['avoid_me']]:
            self.log_event(f"Rejected request from avoided device {from_device.name}")
            return False

        if task_type in self.capabilities:
            if self.negotiate_load(load):
                self.log_event(f"Composite device handled '{task_type}' from {from_device.name}")
                self.update_trust(success=True)
                return True
            else:
                # Try to delegate to workers or sub-devices
                delegated = self.delegate_task(task_type, details)
                if delegated:
                    return True
                for rel in self.relationships['back_me']:
                    backup = rel['device']
                    self.log_event(f"Requesting backup for '{task_type}' from {backup.name}")
                    return backup.handle_request(self, task_type, load)
        else:
            self.log_event(f"Rejected unknown or unsupported task type '{task_type}'")
            return False

    def report_status(self):
        super().report_status()
        print(f"{self.name} | Composite capabilities: {self.capabilities} | "
              f"Sub-devices: {[d.name for d in self.sub_devices]} | "
              f"Workers: {[d.name for d in self.worker_devices]}")
