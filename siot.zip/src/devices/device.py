import random
import time
from ..utils.logger import SimulationLogger

class Device:
    def __init__(self, device_id, name, max_load=100):
        self.device_id = device_id
        self.name = name
        self.max_load = max_load
        self.current_load = 0
        self.trust_score = 100  # 0-100
        self.relationships = {
            'work_with_me': [],
            'work_for_me': [],
            'back_me': [],
            'avoid_me': []
        }
        self.policy = {
            'max_tasks_per_controller': 10,  # Maximum tasks a controller can assign
            'max_load_per_controller': 50,   # Maximum load a controller can assign
            'task_timeout': 300              # 5 minutes timeout for tasks
        }
        self.task_log = []
        self.misuse_count = 0
        self.blame_count = 0
        self.controller_tasks = {}  # Track tasks per controller
        self.logger = SimulationLogger()

    def add_relationship(self, relation_type, device, constraints=None):
        if relation_type in self.relationships:
            self.relationships[relation_type].append({
                'device': device,
                'constraints': constraints or {},
                'start_time': time.time(),
                'status': 'active'
            })

    def avoid(self, device):
        self.relationships['avoid_me'].append({'device': device, 'status': 'active'})
        self.log_event(f"Avoiding device {device.name}")

    def negotiate_load(self, requested_load):
        if self.current_load + requested_load <= self.max_load:
            self.current_load += requested_load
            return True
        else:
            return False

    def reduce_load(self):
        reduced = max(0, self.current_load - random.randint(5, 15))
        self.log_event(f"Reducing load from {self.current_load} to {reduced}")
        self.current_load = reduced

    def update_trust(self, success=True, weight=1):
        change = 5 * weight if success else -10 * weight
        self.trust_score = max(0, min(100, self.trust_score + change))
        self.log_event(f"Trust updated to {self.trust_score}")

    def check_policy(self, relation_type, task_type):
        for rel in self.relationships.get(relation_type, []):
            constraints = rel['constraints']
            if 'forbidden_tasks' in constraints and task_type in constraints['forbidden_tasks']:
                self.log_event(f"Policy violation: {task_type} forbidden in {relation_type}")
                self.penalize()
                return False
        return True

    def penalize(self, amount=10):
        self.trust_score = max(0, self.trust_score - amount)
        self.blame_count += 1
        self.log_event(f"Penalized. Trust: {self.trust_score}, Blames: {self.blame_count}")

    def add_controller(self, controller_device, constraints=None):
        """Add a device as a controller with specific constraints."""
        if not any(d['device'] == controller_device for d in self.relationships['work_for_me']):
            self.relationships['work_for_me'].append({
                'device': controller_device,
                'constraints': constraints or {},
                'start_time': time.time(),
                'status': 'active',
                'task_count': 0,
                'total_load': 0
            })
            self.log_event(f"Added {controller_device.name} as controller")
            return True
        return False

    def remove_controller(self, controller_device):
        """Remove a device from the controller list."""
        self.relationships['work_for_me'] = [
            rel for rel in self.relationships['work_for_me']
            if rel['device'] != controller_device
        ]
        self.log_event(f"Removed {controller_device.name} as controller")

    def is_authorized_controller(self, device):
        """Check if a device is an authorized controller."""
        return any(
            rel['device'] == device and rel['status'] == 'active'
            for rel in self.relationships['work_for_me']
        )

    def check_controller_limits(self, controller_device, load):
        """Check if a controller has exceeded its task or load limits."""
        for rel in self.relationships['work_for_me']:
            if rel['device'] == controller_device:
                if rel['task_count'] >= self.policy['max_tasks_per_controller']:
                    self.log_event(f"Controller {controller_device.name} exceeded max tasks")
                    return False
                if rel['total_load'] + load > self.policy['max_load_per_controller']:
                    self.log_event(f"Controller {controller_device.name} exceeded max load")
                    return False
                return True
        return False

    def update_controller_metrics(self, controller_device, load):
        """Update task and load metrics for a controller."""
        for rel in self.relationships['work_for_me']:
            if rel['device'] == controller_device:
                rel['task_count'] += 1
                rel['total_load'] += load
                break

    def handle_request(self, from_device, task_type, load=10, details=None):
        if from_device in [d['device'] for d in self.relationships['avoid_me']]:
            self.log_event(f"Rejected request from avoided device {from_device.name}")
            return False

        # Check if the request is from an authorized controller
        is_controller = self.is_authorized_controller(from_device)
        
        if is_controller:
            # Check controller-specific limits
            if not self.check_controller_limits(from_device, load):
                self.misuse_count += 1
                self.log_event(f"Rejected task from controller {from_device.name} (exceeded limits)")
                return False

        if not self.check_policy('work_with_me', task_type):
            return False

        if self.negotiate_load(load):
            self.log_event(f"Accepted task {task_type} from {from_device.name}")
            if is_controller:
                self.update_controller_metrics(from_device, load)
            self.update_trust(success=True)
            return True
        else:
            self.misuse_count += 1
            self.log_event(f"Rejected task {task_type} from {from_device.name} (overload)")
            self.update_trust(success=False)
            return False

    def log_event(self, message):
        self.logger.log_info(self.name, message)
        self.task_log.append(message)

    def report_status(self):
        status_msg = (
            f"Trust: {self.trust_score} | "
            f"Load: {self.current_load} | "
            f"Misuses: {self.misuse_count} | "
            f"Blames: {self.blame_count}"
        )
        self.logger.log_info(self.name, status_msg)
