from .device import Device
import random

class SensingDevice(Device):
    def __init__(self, device_id, name, max_load=100, sensor_type="temperature"):
        super().__init__(device_id, name, max_load)
        self.sensor_type = sensor_type

    def sense(self):
        if self.current_load >= self.max_load:
            self.log_event(f"Sensing failed: overloaded.")
            self.update_trust(success=False)
            return None

        value = random.uniform(20.0, 30.0) if self.sensor_type == "temperature" else random.uniform(0.0, 100.0)
        self.current_load += 10
        self.log_event(f"Sensed {self.sensor_type}: {value:.2f}")
        self.update_trust(success=True)
        return value

    def handle_request(self, from_device, task_type, load=10, details=None):
        if from_device in [d['device'] for d in self.relationships['avoid_me']]:
            self.log_event(f"Rejected request from avoided device {from_device.name}")
            return False

        if task_type != 'sense':
            self.log_event(f"Rejected unknown task type '{task_type}'")
            return False

        if self.negotiate_load(load):
            value = self.sense()
            if value is not None:
                self.log_event(f"Accepted sense request from {from_device.name}, value: {value:.2f}")
                self.update_trust(success=True)
                return True
            else:
                # Try backup if available
                for rel in self.relationships['back_me']:
                    backup = rel['device']
                    self.log_event(f"Requesting backup sensing from {backup.name}")
                    return backup.handle_request(self, 'sense', load, details)
        else:
            self.log_event(f"Rejected sense request from {from_device.name} (overload)")
            self.update_trust(success=False)
            return False

    def report_status(self):
        super().report_status()
        print(f"{self.name} | Sensor type: {self.sensor_type}")
