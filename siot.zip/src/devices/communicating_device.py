from .device import Device

class CommunicatingDevice(Device):
    def __init__(self, device_id, name, max_load=100, protocol="WiFi"):
        super().__init__(device_id, name, max_load)
        self.protocol = protocol
        self.connected_devices = []

    def connect_device(self, device):
        if device not in self.connected_devices:
            self.connected_devices.append(device)
            self.log_event(f"Connected to {device.name}")

    def transmit(self, message, target_device):
        if target_device not in self.connected_devices:
            self.log_event(f"Cannot transmit: {target_device.name} not connected")
            self.update_trust(success=False)
            return False

        if self.current_load >= self.max_load:
            self.log_event(f"Transmission failed: overloaded.")
            self.update_trust(success=False)
            return False

        self.current_load += 10
        self.log_event(f"Transmitted '{message}' to {target_device.name} via {self.protocol}")
        self.update_trust(success=True)
        return True

    def handle_request(self, from_device, task_type, load=10, details=None):
        if from_device in [d['device'] for d in self.relationships['avoid_me']]:
            self.log_event(f"Rejected request from avoided device {from_device.name}")
            return False

        if task_type != 'transmit':
            self.log_event(f"Rejected unknown task type '{task_type}'")
            return False

        message = details.get('message') if details else "default message"
        target_device = details.get('target') if details else None

        if not target_device:
            self.log_event(f"No target device provided for transmission")
            return False

        if self.negotiate_load(load):
            success = self.transmit(message, target_device)
            if success:
                self.log_event(f"Accepted transmit request from {from_device.name} to {target_device.name}")
                self.update_trust(success=True)
                return True
            else:
                # Try backup if available
                for rel in self.relationships['back_me']:
                    backup = rel['device']
                    self.log_event(f"Requesting backup transmission from {backup.name}")
                    return backup.handle_request(self, 'transmit', load, details)
        else:
            self.log_event(f"Rejected transmit request from {from_device.name} (overload)")
            self.update_trust(success=False)
            return False

    def report_status(self):
        super().report_status()
        print(f"{self.name} | Protocol: {self.protocol} | Connected: {[d.name for d in self.connected_devices]}")
