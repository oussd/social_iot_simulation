import argparse
from src.simulations.lab_simulation import LabSimulation
from src.simulations.building_simulation import BuildingSimulation


def run_simulation(simulation_type):
    if simulation_type.lower() == 'building':
        print("\n=== BUILDING SIMULATION: Negotiation ON ===")
        BuildingSimulation(negotiation=True, num_devices=10).run()

        print("\n=== BUILDING SIMULATION: Negotiation OFF ===")
        BuildingSimulation(negotiation=False, num_devices=10).run()
    
    elif simulation_type.lower() == 'lab':
        print("\n=== LAB SIMULATION: Negotiation ON ===")
        LabSimulation(negotiation=True, num_devices=10).run()

        print("\n=== LAB SIMULATION: Negotiation OFF ===")
        LabSimulation(negotiation=False, num_devices=10).run()
    
    else:
        print(f"Error: Unknown simulation type '{simulation_type}'")
        print("Please use 'building' or 'lab'")


def main():
    parser = argparse.ArgumentParser(description='Run IoT device simulation')
    parser.add_argument(
        'simulation_type',
        choices=['building', 'lab'],
        help='Type of simulation to run (building or lab)'
    )
    
    args = parser.parse_args()
    run_simulation(args.simulation_type)


if __name__ == "__main__":
    main()
